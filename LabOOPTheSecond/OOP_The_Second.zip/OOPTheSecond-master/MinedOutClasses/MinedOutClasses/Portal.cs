﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Portal : Cell
    {
        public Portal(int x, int y, ConsoleColor color, string symbol) : base(x, y, color, symbol) { }
        
    }
}
