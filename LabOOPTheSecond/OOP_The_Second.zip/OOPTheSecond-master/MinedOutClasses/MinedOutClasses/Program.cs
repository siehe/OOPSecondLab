﻿using System;
using Newtonsoft.Json;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            JsonSerializer sr = new JsonSerializer();
            sr.NullValueHandling = NullValueHandling.Ignore;



            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Green;
            MainMenu Menu = new MainMenu();
            Console.WriteLine("Hello! Sorry, what is your name?");
            string name = Console.ReadLine();
            Player Player = new Player(name);
            Console.Clear();
            Console.WriteLine("Hello, {0}, nice to meet you! Welcome to Mined-Out. Press any key to continue.", name);
            Console.ReadKey();
            Menu.WriteOptions();
            string size = "";
            while(true)
            {
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                size = Menu.MoveOptions(keyInfo);
                if (keyInfo.Key == ConsoleKey.Enter)
                {
                    break;
                }
            }
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Loading...");
            int height;
            if (size == "Small")
            {
                height = 15;
            }
            else if(size == "Medium")
            {
                height = 20;
            }
            else
            {
                height = 30;
            }





            int width = height * 2;
            int mines = (width * height) / 5;
            int hearts = (width * height) / 60;
            int coins = (width * height) / 15;
            Field Field = new Field(height, width);
            Generator FieldGenerator = new Generator(Field, mines, hearts, coins);
            Drawer Drawer = new Drawer();
            Console.Clear();
            FieldGenerator.GenerateField(Field);
            Field.Hero = FieldGenerator.Hero;

            Console.Clear();


            Drawer.DrawField(Field);

            while (true)
            {
                Drawer.WriteStats(Field);
                if (Field.Hero.AbleToMove)
                {
                    ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                    Field.Hero.Move(keyInfo, Field);
                    int CurrX = Field.Hero.X;
                    int CurrY = Field.Hero.Y;
                    if (Field.Cells[CurrY][CurrX] is Mine)
                    {
                        if (Field.Hero.Health == 0)
                        {
                            Field.Hero.AbleToMove = false;
                            Field.Hero.Explode();
                            Drawer.BlowUpMines(Field);
                            break;
                        }
                        else
                        {
                            Field.Cells[CurrY][CurrX] = new EmptyCell(CurrX, CurrY, ConsoleColor.Gray, " ");
                            Field.Hero.Health--;
                        }
                    }
                    else if (Field.Cells[CurrY][CurrX] is Coin)
                    {
                        Field.Hero.BonusPoints++;
                    }
                    else if (Field.Cells[CurrY][CurrX] is Heart)
                    {
                        Field.Hero.Health++;
                    }
                    else if (Field.Cells[CurrY][CurrX] is Escape)
                    {
                        Field.Hero.AbleToMove = false;
                        Drawer.DrawVictory(Field);
                        break;
                    }
                    else if(Field.Cells[CurrY][CurrX] is Portal)
                    {
                        Field.Hero.Teleport(Field);
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
