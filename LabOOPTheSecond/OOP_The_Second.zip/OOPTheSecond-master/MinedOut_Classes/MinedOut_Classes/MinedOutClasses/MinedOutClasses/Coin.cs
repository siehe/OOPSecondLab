﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Coin : BonusCell
    {
        public Coin(int x, int y, ConsoleColor color, string symbol) : base(x, y, color, symbol) { }
    }
}
