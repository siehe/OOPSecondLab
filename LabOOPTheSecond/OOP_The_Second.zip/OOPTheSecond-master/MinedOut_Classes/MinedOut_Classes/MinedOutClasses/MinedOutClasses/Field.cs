﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Field
    {
        public static int Height { get; set; }
        public static int Width { get; set; }
        public int NumberOfMines { get; set; }
        public int NumberHearts { get; set; }
        public int NumberCoins { get; set; }
        public Character Hero { get; set; }
        public static Cell[,] Cells;
        public Field(int height, int width, int mines, int hearts, int coins)
        {
            Height = height;
            Width = width;
            NumberOfMines = mines;
            NumberHearts = hearts;
            NumberCoins = coins;
            Cells = new Cell[Height, Width];
        }

        public void Generate()
        {
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    if (i == 0 || j == 0 || i == Height - 1 || j == Width - 1)
                    {
                        Cells[i, j] = new Wall(j, i, ConsoleColor.Red);
                    }
                    else
                    {
                        Cells[i, j] = new EmptyCell(j, i, ConsoleColor.DarkGray);
                    }
                }
            }
            Cells[2, 2] = new Character(2, 2, ConsoleColor.Green, 3, 0);
            Cells[Height - 2, Width - 2] = new Escape(Width - 2, Height - 2, ConsoleColor.DarkMagenta);
            Hero = (Character)Cells[2, 2];
            DropHearts();
            DropCoins();
            SetMines();
        }


        public void SetMines()
        {
            Random a = new Random();
            while (NumberOfMines != 0)
            {
                int x = a.Next(1, Width - 1);
                int y = a.Next(1, Height - 1);
                if(Cells[y, x] is EmptyCell && Cells[y, x - 1] is Character == false
                    && Cells[y, x + 1] is Character == false && Cells[y - 1, x] is Character == false
                    && Cells[y + 1, x] is Character == false)
                {
                    Cells[y, x] = new Mine(x, y, ConsoleColor.White);
                    NumberOfMines--;
                }
            }
        }

        public void DropHearts()
        {
            Random a = new Random();
            while (NumberHearts != 0)
            {
                int x = a.Next(1, Width - 1);
                int y = a.Next(1, Height - 1);
                if(Cells[y, x] is EmptyCell)
                {
                    Cells[y, x] = new Heart(x, y, ConsoleColor.Cyan, "v");
                }
                NumberHearts--;
            }
        }

        public void DropCoins()
        {
            Random a = new Random();
            while (NumberCoins != 0)
            {
                int x = a.Next(1, Width - 1);
                int y = a.Next(1, Height - 1);
                if (Cells[y, x] is EmptyCell)
                {
                    Cells[y, x] = new Coin(x, y, ConsoleColor.Yellow, "o");
                }
                NumberCoins--;
            }
        }

        public void DrawField()
        {
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Cells[i, j].Draw();
                }
            }
        }

        public void BlowUpMines()
        {
            for(int i = 0; i < Height; i++)
            {
                for(int j = 0; j < Width; j++)
                {
                    if (Cells[i, j] is Mine)
                    {
                        Cells[i, j] = new ExplodedMine(j, i, ConsoleColor.DarkYellow);
                        Cells[i, j].Draw();
                    }
                }
            }
        }

        public void WriteStats()
        {
            Console.SetCursorPosition(Width + 4, 0);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("Health: {0}", Hero.Health);


            Console.SetCursorPosition(Width + 4, 1);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("Bonus points: {0}", Hero.BonusPoints);
        }

        public void DrawVictory()
        {
            Console.BackgroundColor = ConsoleColor.Cyan;
            for (int i = Hero.Y; i > 0; i--)
            {
                for (int j = Hero.X; j > 0; j--)
                {
                    if (i == Hero.Y || j == Hero.X)
                    {
                        Console.SetCursorPosition(j, i);
                        Console.Write(" ");
                        System.Threading.Thread.Sleep(50);
                    }
                }
            }
            for (int i = Hero.Y; i < Height - 1; i++)
            {
                for (int j = Hero.X; j < Width - 1; j++)
                {
                    if (i == Hero.Y || j == Hero.X)
                    {
                        Console.SetCursorPosition(j, i);
                        Console.Write(" ");
                        System.Threading.Thread.Sleep(50);
                    }
                }
            }

            System.Threading.Thread.Sleep(100);
            Console.BackgroundColor = ConsoleColor.Black;
            for(int i = 0; i < Height; i++)
            {
                for(int j = 0; j < Width; j++)
                {
                    System.Threading.Thread.Sleep(10);
                    Console.SetCursorPosition(j, i);
                    Console.Write(" ");
                }
            }
        }
    }
}
