﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.Green;
            MainMenu Menu = new MainMenu();
            Console.WriteLine("Hello! Sorry, what is your name?");
            string name = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Hello {0}, nice to meet you! Welcome to Mined-Out. Press any key to comtinue.", name);
            Console.ReadKey();
            Menu.WriteOptions();
            string size = "";
            while(true)
            {
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                size = Menu.MoveOptions(keyInfo);
                if (keyInfo.Key == ConsoleKey.Enter)
                {
                    break;
                }
            }
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Loading...");
            int height;
            if (size == "Small")
            {
                height = 15;
            }
            else if(size == "Medium")
            {
                height = 20;
            }
            else
            {
                height = 30;
            }





            int width = height * 2;
            int mines = (width * height) / 10;
            int hearts = (width * height) / 40;
            int coins = (width * height) / 15;
            Field Field = new Field(height, width, mines, hearts, coins);
            Field.Generate();
            Console.Clear();
            Field.DrawField();
            
            while(true)
            {
                Field.WriteStats();
                if (Field.Hero.AbleToMove)
                {
                    ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                    Field.Hero.Move(keyInfo);
                    int CurrX = Field.Hero.X;
                    int CurrY = Field.Hero.Y;
                    if (Field.Cells[CurrY, CurrX] is Mine)
                    {
                        if (Field.Hero.Health == 0)
                        {
                            Field.Hero.AbleToMove = false;
                            Field.Hero.Explode();
                            Field.BlowUpMines();
                            break;
                        }
                        else
                        {
                            Field.Cells[CurrY, CurrX] = new ExplodedMine(CurrX, CurrY, ConsoleColor.DarkYellow);
                            Field.Hero.Health--;
                        }
                    }
                    else if (Field.Cells[CurrY, CurrX] is Coin)
                    {
                        Field.Hero.BonusPoints++;
                    }
                    else if (Field.Cells[CurrY, CurrX] is Heart)
                    {
                        Field.Hero.Health++;
                    }
                    else if (Field.Cells[CurrY, CurrX] is Escape)
                    {
                        Field.Hero.AbleToMove = false;
                        Field.DrawVictory();
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
