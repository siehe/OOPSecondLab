﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinedOutClasses
{
    class Character : Cell
    {
        public int Health { get; set; }
        public string Symbol { get; set; }
        public int BonusPoints { get; set; }
        public bool AbleToMove { get; set; }
        public Character(int x, int y, ConsoleColor color, int health, int bonus):base(x, y, color)
        {
            Health = health;
            BonusPoints = bonus;
            Symbol = CountMines();
            AbleToMove = true;
        }

        public override void Draw()
        {
            Console.BackgroundColor = Color;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(X, Y);
            Console.Write(Symbol);
        }

        public void DrawStep(int DeltaX, int DeltaY)
        {
            Console.SetCursorPosition(X, Y);
            Console.BackgroundColor = ConsoleColor.Gray;
            Console.Write(" ");
            Console.SetCursorPosition(X + DeltaX, Y + DeltaY);
            Console.BackgroundColor = Color;
            Console.ForegroundColor = ConsoleColor.White;
            X += DeltaX;
            Y += DeltaY;
            Console.Write(CountMines());
        }

        public string CountMines()
        {
            int res = 0;
            if (Field.Cells[Y + 1, X] is Mine) res++;
            if (Field.Cells[Y - 1, X] is Mine) res++;
            if (Field.Cells[Y, X + 1] is Mine) res++;
            if (Field.Cells[Y, X - 1] is Mine) res++;
            return res.ToString();
        }

        public void Move(ConsoleKeyInfo KeyInfo)
        {
            switch(KeyInfo.Key)
            {
                case ConsoleKey.UpArrow:
                    if(Y - 1 > 0)
                    {
                        DrawStep(0, - 1);
                    }
                    break;
                case ConsoleKey.DownArrow:
                    if(Y + 1 < Field.Height - 1)
                    {
                        DrawStep(0, 1);
                    }
                    break;
                case ConsoleKey.RightArrow:
                    if(X + 1 < Field.Width - 1)
                    {
                        DrawStep(1, 0);
                    }
                    break;
                case ConsoleKey.LeftArrow:
                    if(X - 1 > 0)
                    {
                        DrawStep(-1, 0);
                    }
                    break;
            }
        }

        public void Explode()
        {
            Console.SetCursorPosition(X, Y);
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write(" ");
        }
    }
}
